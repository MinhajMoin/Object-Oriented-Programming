#pragma once

struct Color
{
    int red;
    int green;
    int blue;

    Color()
    {
        red = 255;
        green = 255;
        red = 255;
    }

    Color(int red, int green, int blue)
    {
        this->red = red;
        this->green = green;
        this->blue = blue;
    }
};
